/*
 * q4.cpp
 *
 *  Created on: 11-Oct-2024
 *      Author: root
 */




