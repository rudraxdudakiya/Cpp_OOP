/*
 * q2.cpp
 *
 *  Created on: 10-Oct-2024
 *      Author: root
 */

//Design a baseclass Patient and IPD(ward_no,bed_no,charge_per_day).Derive a class
//IPD-Patient from these two base classes with no_of_days admitted.

#include <iostream>
using namespace std;

class Patient
{
protected:
	int p_id;
	string name;
	int age;
};

class IPD
{
protected:
	int ward_no, bed_no;
	float CPD;
	string disease;
};

class IPD_Patient : public Patient, public IPD
{
	int dd,mm,yy;
	int d,m,y;
	int days;
public:
	void input()
	{
		cout << "\n\nEnter the details of patient\n\n"
				"Patient id : ";
		cin >> p_id;
		cout << "Name       : ";
		cin >> name;
		cout << "Age        : ";
		cin >> age;

		cout << "\nDisease : ";
		cin >> disease;
		cout << "Ward no    : ";
		cin >> ward_no;
		cout << "Bed no     : ";
		cin >> bed_no;
		cout << "Charges per day : ";
		cin >> CPD;

		cout << "\nAdmit date (dd-mm-yy) : ";
		cin >> dd >> mm >> yy;

		cout << "Enter total days : ";
		cin >> days;
	}
	void display()
	{
		cout << "\n\nPatient Details :\n" << endl;
		cout << "Patient ID      : " << p_id << endl;
		cout << "Name            : " << name << endl;
		cout << "Age             : " << age << endl;
		cout << "Disease         : " << disease << endl;
		cout << "WardNo          : " << ward_no << endl;
		cout << "BedNo           : " << bed_no << endl;
		cout << "Charges per day : " << CPD << "$" << endl;
		cout << "Admit date      : " << dd<<"/"<<mm<<"/"<<yy << endl;
		cout << "Total days      : " << days << endl;
		cout << "Total Bill      : " << days * CPD << "$";
	}
};
int main()
{
	int n;
	cout << "Enter the number of patients :";
	cin >> n;
	IPD_Patient p[n];
	for(int i=0; i<n; i++)
	{
		cout << "\n\nPatient no : " << i+1 << endl;
		p[i].input();
	}
	for(int i=0; i<n; i++)
	{
		cout << "\n\nPatient no : " << i+1 << endl;
		p[i].display();
	}
	return 0;
}
